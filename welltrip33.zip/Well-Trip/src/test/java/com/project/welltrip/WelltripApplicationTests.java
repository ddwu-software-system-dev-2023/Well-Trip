package com.project.welltrip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WelltripApplicationTests {

	@Test
	void contextLoads() {
	}

}
